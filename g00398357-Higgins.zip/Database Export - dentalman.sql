-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.22-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.0.0.6468
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for dentalman
CREATE DATABASE IF NOT EXISTS `dentalman` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `dentalman`;

-- Dumping structure for procedure dentalman.AddAppointment
DELIMITER //
CREATE PROCEDURE `AddAppointment`()
BEGIN


-- SELECT * FROM appointments WHERE appointments.Date = '2022/04/28';

-- IF SELECT FOR DATE AND TIME RANGE IS NULL THEN ADD APPOINTMENT IF NOT CAN I POP AN ERROR MESSAGE?

SET @treatment = '3';
SET @patientID = '6';
SET @DATE = '2022-05-04';
SET @TIME = '10:00:00';
SET @staffID = '1';


SELECT appointments.DATE = @DATE AND appointments.Time = @TIME FROM appointments;


END//
DELIMITER ;

-- Dumping structure for table dentalman.appointments
CREATE TABLE IF NOT EXISTS `appointments` (
  `PatientID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `TreatmentID` int(11) DEFAULT NULL,
  `Cancelled` int(11) DEFAULT 0 COMMENT '0 No / 1 Yes / 2 Late',
  `StaffID` int(11) NOT NULL,
  `Cost` float unsigned DEFAULT NULL,
  `AmtPaid` float unsigned DEFAULT NULL,
  `FullyPaid` int(11) DEFAULT 0 COMMENT '0 No / 1 Yes',
  `DentistNotes` longtext DEFAULT NULL,
  `Billed` int(11) DEFAULT 0 COMMENT '0 No / 1 Yes',
  `checkedIn` int(11) DEFAULT 0 COMMENT '0 No / 1 Yes',
  PRIMARY KEY (`PatientID`,`Date`,`Time`),
  KEY `FK_appointments_treatments` (`TreatmentID`),
  KEY `FK_appointments_staff` (`StaffID`),
  CONSTRAINT `FK_appointments_staff` FOREIGN KEY (`StaffID`) REFERENCES `staff` (`staffID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_appointments_treatments` FOREIGN KEY (`TreatmentID`) REFERENCES `treatments` (`treatmentID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `PatientID` FOREIGN KEY (`PatientID`) REFERENCES `patients` (`PatientID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.appointments: ~16 rows (approximately)
INSERT INTO `appointments` (`PatientID`, `Date`, `Time`, `TreatmentID`, `Cancelled`, `StaffID`, `Cost`, `AmtPaid`, `FullyPaid`, `DentistNotes`, `Billed`, `checkedIn`) VALUES
	(1, '2022-04-25', '09:00:00', 1, NULL, 1, 50, NULL, 0, NULL, 1, 0),
	(1, '2022-04-25', '09:30:00', 2, NULL, 1, 90, NULL, 0, NULL, 1, 0),
	(3, '2022-04-26', '11:00:00', 3, NULL, 1, 500, NULL, 0, NULL, 1, 0),
	(4, '2022-04-27', '09:00:00', 1, NULL, 1, 50, NULL, 0, NULL, 1, 0),
	(5, '2022-04-28', '09:00:00', 1, NULL, 1, 50, NULL, 0, NULL, 1, 0),
	(5, '2022-04-28', '10:00:00', 1, NULL, 1, 50, NULL, 0, NULL, 1, 0),
	(5, '2022-04-28', '12:00:00', 1, NULL, 1, 50, NULL, 0, NULL, 1, 0),
	(5, '2022-04-28', '14:00:00', 1, 0, 1, 50, NULL, 0, NULL, 1, 0),
	(6, '2022-04-28', '16:00:00', 2, 0, 1, 90, NULL, 0, NULL, 0, 1),
	(6, '2022-04-29', '16:00:00', 2, 0, 1, 90, NULL, 0, NULL, 0, 1),
	(6, '2022-05-03', '16:00:00', 3, 0, 1, 500, NULL, 0, NULL, 0, 1),
	(6, '2022-05-04', '10:00:00', 3, 0, 1, 500, NULL, 0, NULL, 0, 0),
	(7, '2022-05-11', '10:00:00', 1, 0, 1, 50, NULL, 0, NULL, 0, 0),
	(7, '2022-05-13', '10:00:00', 4, 0, 1, 5000, NULL, 0, NULL, 0, 0),
	(8, '2022-05-20', '10:00:00', 1, 0, 1, 50, NULL, 0, NULL, 0, 0),
	(9, '2022-05-26', '11:00:00', 1, 1, 1, 50, NULL, 0, NULL, 0, 0);

-- Dumping structure for table dentalman.bills
CREATE TABLE IF NOT EXISTS `bills` (
  `billno` int(11) NOT NULL AUTO_INCREMENT,
  `amount` float DEFAULT NULL,
  `patientID` int(11) DEFAULT NULL,
  PRIMARY KEY (`billno`),
  KEY `FK_bills_patients` (`patientID`),
  CONSTRAINT `FK_bills_patients` FOREIGN KEY (`patientID`) REFERENCES `patients` (`PatientID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.bills: ~2 rows (approximately)
INSERT INTO `bills` (`billno`, `amount`, `patientID`) VALUES
	(1, 550, 6),
	(2, 730, 6);

-- Dumping structure for view dentalman.nextweek
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `nextweek` (
	`PatientID` INT(11) NOT NULL,
	`Date` DATE NOT NULL,
	`Time` TIME NOT NULL,
	`TreatmentID` INT(11) NULL,
	`Cancelled` INT(11) NULL COMMENT '0 No / 1 Yes / 2 Late',
	`StaffID` INT(11) NOT NULL,
	`Cost` FLOAT UNSIGNED NULL,
	`AmtPaid` FLOAT UNSIGNED NULL,
	`FullyPaid` INT(11) NULL COMMENT '0 No / 1 Yes',
	`DentistNotes` LONGTEXT NULL COLLATE 'utf8mb4_general_ci',
	`Billed` INT(11) NULL COMMENT '0 No / 1 Yes'
) ENGINE=MyISAM;

-- Dumping structure for table dentalman.patients
CREATE TABLE IF NOT EXISTS `patients` (
  `PatientID` int(8) NOT NULL AUTO_INCREMENT,
  `Name` char(50) NOT NULL DEFAULT '',
  `address` char(100) DEFAULT NULL,
  `outstandingBalance` float unsigned NOT NULL DEFAULT 0,
  `phoneNo` char(50) DEFAULT NULL,
  `emailAddress` char(50) DEFAULT NULL,
  `dateOfBirth` date DEFAULT NULL,
  PRIMARY KEY (`PatientID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.patients: ~9 rows (approximately)
INSERT INTO `patients` (`PatientID`, `Name`, `address`, `outstandingBalance`, `phoneNo`, `emailAddress`, `dateOfBirth`) VALUES
	(1, 'Derek', '1 The Green', 40, NULL, NULL, '2002-05-03'),
	(2, 'Mary', '2 The Hermitage', 0, NULL, NULL, '2000-01-03'),
	(3, 'Ollie', '47 Oakglen Park', 500, NULL, NULL, '1983-05-10'),
	(4, 'Liam', '2 McCarthy Cross', 50, NULL, NULL, '1989-07-22'),
	(5, 'Tara', '24 Blackglen Avenue', 200, NULL, NULL, NULL),
	(6, 'Roisin', '5 Gorm Green', 50, NULL, NULL, NULL),
	(7, 'Bruce', NULL, 0, NULL, NULL, NULL),
	(8, 'Jess', NULL, 0, NULL, NULL, NULL),
	(9, 'Freddy', NULL, 50, NULL, NULL, NULL);

-- Dumping structure for table dentalman.payments
CREATE TABLE IF NOT EXISTS `payments` (
  `patientID` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `amount` float NOT NULL,
  `paymentType` int(11) DEFAULT NULL COMMENT '0 Cash / 1 Card / 2 Cheque',
  `paidWhere` int(11) DEFAULT NULL COMMENT '0 In Person / 2 Post / 3 By Phone',
  `billno` int(11) DEFAULT NULL,
  PRIMARY KEY (`patientID`,`date`,`time`),
  KEY `FK_payments_bills` (`billno`),
  CONSTRAINT `FK_payments_bills` FOREIGN KEY (`billno`) REFERENCES `bills` (`billno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_payments_patients` FOREIGN KEY (`patientID`) REFERENCES `patients` (`PatientID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.payments: ~3 rows (approximately)
INSERT INTO `payments` (`patientID`, `date`, `time`, `amount`, `paymentType`, `paidWhere`, `billno`) VALUES
	(1, '2022-05-03', '05:45:12', 100, 0, 0, 1),
	(1, '2022-05-03', '05:46:46', 100, 0, 0, 1),
	(1, '2022-05-03', '10:00:00', 100, 0, 0, 1);

-- Dumping structure for table dentalman.referrals
CREATE TABLE IF NOT EXISTS `referrals` (
  `patientID` int(11) NOT NULL,
  `specialistID` int(11) NOT NULL,
  `date` date NOT NULL,
  `reportID` int(11) DEFAULT NULL,
  `reportDate` date DEFAULT NULL,
  PRIMARY KEY (`patientID`,`specialistID`,`date`),
  KEY `FK_referrals_specialists` (`specialistID`),
  CONSTRAINT `FK__patients` FOREIGN KEY (`patientID`) REFERENCES `patients` (`PatientID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_referrals_specialists` FOREIGN KEY (`specialistID`) REFERENCES `specialists` (`specialistID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.referrals: ~1 rows (approximately)
INSERT INTO `referrals` (`patientID`, `specialistID`, `date`, `reportID`, `reportDate`) VALUES
	(1, 1, '2022-05-03', NULL, NULL);

-- Dumping structure for table dentalman.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `roleID` int(11) NOT NULL AUTO_INCREMENT,
  `roleTitle` char(50) DEFAULT NULL,
  PRIMARY KEY (`roleID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.roles: ~2 rows (approximately)
INSERT INTO `roles` (`roleID`, `roleTitle`) VALUES
	(1, 'Dentist'),
	(2, 'Secretary');

-- Dumping structure for table dentalman.specialists
CREATE TABLE IF NOT EXISTS `specialists` (
  `specialistID` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) DEFAULT NULL,
  `address` char(255) DEFAULT NULL,
  PRIMARY KEY (`specialistID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.specialists: ~2 rows (approximately)
INSERT INTO `specialists` (`specialistID`, `name`, `address`) VALUES
	(1, 'Dr. Rasheen Viktor', '1 Pall Mall'),
	(2, 'Prof. McCarthy', '2 Mayfair');

-- Dumping structure for table dentalman.staff
CREATE TABLE IF NOT EXISTS `staff` (
  `staffID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` char(50) DEFAULT NULL,
  `RoleID` int(11) DEFAULT NULL,
  PRIMARY KEY (`staffID`),
  KEY `FK_staff_roles` (`RoleID`),
  CONSTRAINT `FK_staff_roles` FOREIGN KEY (`RoleID`) REFERENCES `roles` (`roleID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.staff: ~3 rows (approximately)
INSERT INTO `staff` (`staffID`, `Name`, `RoleID`) VALUES
	(1, 'Mary Mulcahy', 1),
	(2, 'Helen', 2),
	(3, 'Mark', 1);

-- Dumping structure for table dentalman.treatments
CREATE TABLE IF NOT EXISTS `treatments` (
  `treatmentID` int(11) NOT NULL AUTO_INCREMENT,
  `title` char(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `duration` time DEFAULT NULL,
  PRIMARY KEY (`treatmentID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table dentalman.treatments: ~4 rows (approximately)
INSERT INTO `treatments` (`treatmentID`, `title`, `description`, `cost`, `duration`) VALUES
	(1, 'Filling', 'Simple filling of tooth cavity', 60, '00:30:00'),
	(2, 'Extraction', 'Extraction of tooth', 90, '01:00:00'),
	(3, 'Root Canal', 'Root canal on tooth', 500, '02:00:00'),
	(4, 'Veneer', 'Veneer treatment to tooth', 5000, '01:30:00');

-- Dumping structure for view dentalman.nextweek
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `nextweek`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `nextweek` AS SELECT * FROM appointments WHERE

-- appointments.Date BETWEEN "2022-04-25" AND "2022-05-01" 

appointments.Date BETWEEN SYSDATE() AND DATE_ADD(SYSDATE(), INTERVAL 7 DAY) ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
